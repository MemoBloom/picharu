# 项目文档导航与决策总览

> 文档基线：2026-10-19。面向日本普通消费者；香港公司经营；首期使用商用图像 API；以下“目标”不是已通过实测的指标。

## 推荐阅读顺序

1. `01_PRODUCT_VISION.md`：产品定位与范围。
2. `02_SYSTEM_ARCHITECTURE.md`：部署拓扑与服务职责。
3. `03_API_CONTRACTS.md`：跨 Agent 冻结协议。
4. `04_IMAGE_PIPELINE.md`：上传、推荐、生成、下载闭环。
5. `05_JEV_RECOMMENDATION.md`：美国 Lambda 上的 JEV 推荐。
6. `06_PROMPT_LIBRARY.md`：20–50 个成熟模板的结构、版本、推荐知识。
7. `07_AUTH_BILLING_DATA.md`：Supabase Auth、Stripe 香港、积分账本、数据库与退款。
8. `08_FEATURE_CATALOG.md` / `.csv`：20 个首发候选及质量门槛。
9. `09_MULTI_AGENT_EXECUTION.md`：Codex/Kimi/Pi 分工及集成方法。
10. `10_TESTING_RELEASE.md`：测试、验收、灰度与风险。
11. `11_JAPAN_GROWTH.md`：日语 SEO 与早期获客。
12. `12_DECISIONS_AND_OPEN_QUESTIONS.md`：已定事项 / 未验证依赖。

## 项目一言以蔽之

日本普通消费者上传图片，JEV 类轻量视觉模型据照片内容和模板的丰富适用知识，推荐合适的编辑效果与成熟 Prompt；用户也可直接选工具或自由描述；由第三方 GPT Image / Nano Banana 等图像编辑 API 执行；网站提供透明积分付费、历史和继续编辑。优先低门槛、质量、低成本快速验证，不自研生成模型。

## 正式确定的系统边界

| 领域 | MVP 默认方案 |
|---|---|
| 网站与轻量业务 API | Next.js/TypeScript，部署 Vercel 东京 |
| 身份和持久化 | Supabase Auth + PostgreSQL，东京项目 |
| 图片对象存储 | 私有 Cloudflare R2（区域位置提示不等于日本境内保证） |
| 图像理解推荐 | 已有美国 Lambda GPU，部署 JEV + FastAPI |
| 长任务执行 | Google Cloud Run 东京 CPU Worker，初期可不加 Cloud Tasks |
| 图像生成 | 1–2 个经授权验证的商用模型中转端点 |
| Prompt | Git 管理的 20–50 个 JSON 模板；Next.js 服务端编译读取 |
| 收款 | 香港公司 Stripe Hong Kong（需企业账户和审核） |

## 非目标

不做 Canva 式画布/专业设计工作流；不批量接入数十模型；不自研、训练或微调模型；不做向量数据库、通用 Agent 编排、复杂动态 Prompt 同步。智能扩图已有低价值实测，**不进入首发**。

## 执行准则

- `SPEC`：明确协议和验收；`HYPOTHESIS`：市场、效果、成本或时延待测试；`BLOCKED`：需证件、资质、供应商审核或 API 访问权限。
- 任何服务必须能用 mock 开发，并能在 staging 进行真实跨服务集成。
- 个人照片不得公开；涉及图像和支付的生产接口默认私有、授权、可审计。
- 未经实测，不要把指定模型版本、单张价格或 200–500ms 的 JEV 估算当作保证。
