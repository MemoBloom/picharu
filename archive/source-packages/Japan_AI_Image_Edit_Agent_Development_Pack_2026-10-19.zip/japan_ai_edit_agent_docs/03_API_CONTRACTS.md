# 跨 Agent API 契约（冻结前草案）

> 文档基线：2026-10-19。面向日本普通消费者；香港公司经营；首期使用商用图像 API；以下“目标”不是已通过实测的指标。

## 通用约定

- HTTP JSON：`snake_case`；TypeScript/Python 各自通过代码生成或映射适配。UTC ISO8601 日期；时间耗时 ms；积分为整数。
- `image_id`、`job_id`、`prompt_id`、`tool_id` 使用稳定的内部标识；R2 签名 URL 不充当永久 ID。
- 错误统一：`{ "error": {"code":"...","message":"...","request_id":"...","retryable":false} }`；常用码 `UNAUTHORIZED`, `NOT_FOUND`, `IMAGE_NOT_READY`, `INSUFFICIENT_CREDITS`, `PROVIDER_TIMEOUT`, `RATE_LIMITED`, `INVALID_PROMPT`。
- 浏览器 API 使用 Supabase Session；内部 Lambda/Cloud Run 使用不同的服务间认证；所有修改操作具有幂等语义。

## API 清单

| Method | Path | 请求核心字段 | 响应 |
|---|---|---|---|
| POST | `/api/images/upload-url` | `mime_type, bytes` | `image_id, upload_url, expires_at` |
| POST | `/api/images/complete` | `image_id` | `image_id, status=ready, preview_url` |
| POST | `/api/recommend` | `image_id` 或短缩图 multipart（授权） | `recommendations[]` |
| POST internal | Lambda `/v1/recommend` | `request_id, image, candidates[], top_k` | `prompt_id, score, reason_code` |
| POST | `/api/edit` | `image_id, tool_id, prompt_id?, user_instruction?, idempotency_key` | `job_id, status, credits_reserved` |
| GET | `/api/jobs/:id` | path | `job_id,status,result_image_id?,error?` |
| GET | `/api/credits` | Session | `available,reserved` |
| GET | `/api/credit-packages` | none | 服务端套餐列表 |
| POST | `/api/checkout` | `package_id` | `checkout_url` |
| POST | `/api/stripe/webhook` | Stripe 签名原始 body | 处理完成 / 可重试错误 |
| POST internal | Cloud Run `/process-job` | `job_id` | 作业最终结果/明确错误 |

## 核心类型示例

```typescript
export type JobStatus = 'queued'|'processing'|'completed'|'failed'|'cancelled';
export type RecommendationCandidate = {
  prompt_id: string; tool_id: string;
  name_ja: string; intent: string;
  suitable_subjects: string[];
  visual_requirements: string[];
  negative_conditions: string[];
  expected_result: string;
  category: string;
};
export type Recommendation = {
  prompt_id: string; score: number; reason_code?: string;
};
export type EditRequest = {
  image_id: string; tool_id: string; prompt_id?: string;
  user_instruction?: string; idempotency_key: string;
  output?: { quality?: 'standard'|'high'; aspect_ratio?: string };
};
export type GenerationJob = {
  job_id: string; user_id: string; input_image_ids: string[];
  tool_id: string; prompt_id: string|null; prompt_version: number|null;
  final_prompt: string; provider_model_id: string;
  status: JobStatus; reserved_credits: number;
  provider_job_id?: string|null; result_image_id?: string|null;
};
```

## Lambda 推荐输入输出

```json
{
  "request_id": "rec-001", "top_k": 5,
  "image": {"url":"https://short-lived-signed-url","width":768,"height":432},
  "candidates": [
    {"prompt_id":"pet_watercolor","tool_id":"pet_illustration",
     "name_ja":"ペット水彩イラスト","intent":"pet watercolor portrait",
     "suitable_subjects":["dog","cat"],
     "visual_requirements":["Clearly visible main pet"],
     "negative_conditions":["Severe occlusion"],
     "expected_result":"Watercolor while preserving markings", "category":"pet"}
  ]
}
```

```json
{"request_id":"rec-001","model_version":"jev-pinned","inference_ms":320,
 "recommendations":[{"prompt_id":"pet_watercolor","score":0.89,"reason_code":"CLEAR_PET_SUBJECT"}]}
```

**注意**：得分是否为校准概率取决于模型，需要基准测定；客户端仅接收服务端白名单验证通过的 ID。`top_k` 默认 5，响应项按 score 排序。JEV 不返回需要执行的完整 Prompt。

## Edit 契约与任务快照

- `POST /api/edit` 验证身份、文件归属、模板已启用、参数及用户额度；后端自行决定模型和真实积分费用。
- 组装 `final_prompt` 并写入不可变任务快照；创建任务+预留积分需同一 PG 事务。
- 响应 `202` 含 `job_id`；重复 `idempotency_key` 必须复用原任务。
- Cloud Run 请求只传 `job_id`；Worker 从 PG 读取快照，不重新解释前端参数也不访问 Prompt Library。
- `completed` 仅在结果已写 R2、结果归属已登记、积分已结算后出现。

## 推荐目录同步契约

20–50 个模板采用 **随每次请求发送完整 Recommendation Profile 的元数据**；GitHub→Vercel 构建为权威来源；不建 Catalog API、Redis 或 Lambda 同步进程。推荐发生在部署版本切换附近时，创建任务必须再次验证 prompt 是否有效；已创建任务不受后续模板升级影响。

## 模块所有权

`packages/contracts` 由集成负责人批准更新；`packages/prompts` Prompt Agent；`apps/web` Web Agent；`apps/jev-service` JEV Agent；`apps/worker` Worker Agent；`supabase/migrations` DB/Billing Agent。变更 API 必须先 PR 更新契约和 Mock，再提交实现。
