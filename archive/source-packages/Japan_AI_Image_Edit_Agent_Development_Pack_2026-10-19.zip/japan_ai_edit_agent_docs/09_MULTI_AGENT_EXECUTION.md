# Codex / Kimi / Pi 并行开发与集成

> 文档基线：2026-10-19。面向日本普通消费者；香港公司经营；首期使用商用图像 API；以下“目标”不是已通过实测的指标。

## 必须先做的 D0 工作

技术集成人员冻结 `packages/contracts` 的 OpenAPI/Schema、任务状态与积分事务；提供 Mock 服务器、Mock 图像输出、固定 20 个 Tool ID。所有 Agent 独立 Worktree；共享文件变更由负责人批准。

## Agent 划分

| Agent/角色 | 文件所有权 | 交付物 | 不要修改 |
|---|---|---|---|
| Codex A Web | `apps/web` | 日语 SEO 页、上传、推荐卡片、结果对比、登录/充值 UI | PG migrations/模型权重 |
| Codex B Auth/Billing | `supabase` 及指定 Vercel Billing API | Google/邮箱 Auth、订单、积分事务、Stripe Webhook | Prompt 内容 |
| Pi JEV | `apps/jev-service` | Lambda 部署、`/v1/recommend`、质量/延迟评测 | 真实生成服务与支付 |
| Kimi Worker | `apps/worker` | Cloud Run 部署、上游模型 API、重试、结果存储和结算 | Web 页面和 Prompt 选择 |
| Prompt/QA Agent | `packages/prompts`, `benchmarks` | 20–50 模板、样本、效果验收记录 | 数据库/支付 |
| Integration Owner | `packages/contracts`, CI, release | 契约审核、Mock、合并、端到端可部署版本 | 避免替 Agent 私改业务功能 |

工具选取可替换，目录所有权和接口边界不能混乱。

## Monorepo 建议

```text
apps/web                 # Vercel
apps/worker              # GCP Cloud Run
apps/jev-service         # Lambda GPU
packages/contracts       # 集成负责人维护
packages/prompts         # Prompt Agent
packages/tool-config     # 工具配置
supabase/migrations      # DB Agent
benchmarks/              # 测试样本与脚本
docs/                    # 本资料包
.github/workflows/       # CI
```

## 高速并行验收节点（目标排期，非保证）

- D0：契约、Mock、迁移版本、部署环境和 Git Worktree 就绪。
- D1–3：Web 上传与展示、Auth Mock、JEV API、图片编辑中转 API、R2、任务 Worker 分别独立完成。
- D4–5：**真实上传→选择/推荐→第三方模型编辑→R2 保存→展示**，有可观测日志。
- D6–10：Google/邮箱登录、免费额度、连续编辑、至少 10 个通过评测的工具、Stripe Test Mode。
- D11–21：受控邀请 Beta、质量筛选下一批工具、积分支付和风控；正式收费取决于香港账户和 Stripe 审核。
- D22–30：争取完成 20 个候选功能验收、日语网页优化、用户测试与渠道实验；不达标功能不强行开放。

## 合并纪律

- 每个 PR 写清：契约版本、所改目录、如何测试、Mock 与真实服务差异、失败或遗留项。
- 每次提交运行 Schema/类型检查、单元测试、静态检查、密钥扫描；每日 staging 真实全链路 Smoke Test。
- 生产部署可一键回滚；schema 执行迁移前先评估兼容性；支付和扣费必须人工复核。
- 不允许多个 Agent 同时修改同一 migration / Prompt ID / OpenAPI 文件。跨模块变更先契约 PR 后实现。

## 每个子任务的 Definition of Done

有功能演示、匹配契约的接口、自动化测试、失败路径、必要指标与成本日志、部署/回滚步骤、不会泄露密钥/用户图片。代码提交并不等于任务完成。
