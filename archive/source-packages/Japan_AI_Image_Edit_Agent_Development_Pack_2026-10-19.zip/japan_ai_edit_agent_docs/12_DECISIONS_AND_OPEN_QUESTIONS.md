# 已定决策与待验证事项

> 文档基线：2026-10-19。面向日本普通消费者；香港公司经营；首期使用商用图像 API；以下“目标”不是已通过实测的指标。

## 已定决策 (DECIDED)

- 日本普通消费者、低价按需的 AI 图片编辑聚合站，非 Canva 式综合画布。
- 约 20 个可验证工具入口，Prompt Library 长期限制 20–50 个成熟模板；智能扩图不再首发。
- 首期 GPT Image / Nano Banana 一类商用 API，选择 1–2 个有效端点；不自研模型。
- 用户自选工具与 JEV 智能推荐并行存在；另有自由 Prompt 和连续编辑。
- Prompt JSON 位于 GitHub；Vercel 读取全部已启用模板的**丰富推荐资料**传给 JEV；JEV 回传 Top-K ID；Vercel 组装完整 Prompt 并保存生成快照；Worker 无需同步模板库。
- Vercel 东京承担前端+轻量业务 API；Supabase 东京承担 Auth/PG；美国已有 Lambda GPU 部署 JEV；Cloud Run 东京执行长任务；R2 私有对象存储；Stripe Hong Kong 负责支付。
- Agent 并行且必须冻结接口契约；图像与资金流有统一 ID、状态与幂等。

## 待验证事项 (HYPOTHESIS / BLOCKED)

| 事项 | 责任 | 放行条件 |
|---|---|---|
| 具体 JEV 模型实现/许可证/API | JEV Agent | 真实可商用权重、Top-3 推荐与性能基准 |
| JEV 200–500 ms 推理适用范围 | JEV Agent | GPU/候选数量/热启动真实 P50/P95 |
| 图片传输选 R2 拉取还是 Vercel 缩图转发 | Web + JEV | 真实日本网络链路对比并确认安全 |
| 商用图像模型实际产品版本与中转 endpoint | Worker Agent | 端点、价格、授权、隐私/再提供权确认 |
| 20 项功能通过质量标准的数量 | Prompt QA | 每个 ≥15 图的实测结果 |
| 云存储数据驻留/日本个人数据跨境处理 | 产品/合规 | 供应商条款及专业意见 |
| 香港公司银行账户和 Stripe 正式激活 | 经营负责人 | 企业账户开户、Stripe 合规审核通过 |
| 日语关键词量/真正竞品与市场转化 | Growth | Google 日本数据、有效付费实测 |
| 积分价格和免费额度 | Billing + Finance | 每合格结果成本、手续费和毛利测算 |
| Worker 持久触发方式（PG 扫描/Cloud Tasks） | Worker + Integration | 真实超时/重复/掉队情景通过 |

## 变更控制

任何与此文件不同的结论要在 PR 内更新本决策表；架构改变只在出现真实瓶颈或可靠验收需求时提出，避免把“未来可能扩展”变成 MVP 必做项目。
