# Japan Consumer AI Image Edit — Work 项目资料包

版本：2026-10-19。**目标：日本普通消费者，轻量 AI 图片编辑聚合站。**

## 建议阅读顺序
1. `DECISIONS_AND_ASSUMPTIONS.md` — 已确认决策与未知事项。
2. `PRODUCT_PRD.md` — 产品定位、用户任务、MVP 与业务规则。
3. `UX_SCREEN_SPEC.md` — 页面与用户体验规范。
4. `PHASE1_COMMERCIAL_API_MVP.md` — 商用 API 首发方案（执行基线）。
5. `TECH_ARCHITECTURE_PHASE1.md` — 简化技术架构。
6. `ROADMAP_AGENT_TASKS.md` — 多 Agent 并行任务与验收。
7. `GO_TO_MARKET_JAPAN.md`、`JAPAN_IMAGE_SEO_PLAN.md` — 增长与 SEO。
8. `IMAGE_EDIT_FEATURE_CATALOG.md`、`IMAGE_EDIT_FEATURE_CATALOG.csv` — 56 项长期功能库。
9. `IMAGE_EDIT_MODEL_MATRIX.md`、`IMAGE_EDIT_BENCHMARK.md` — 长期模型调查/完整评测参考，不等于首期工作承诺。

## 一句基线
**先用 1–2 个经合法授权的商用图片编辑 API 端点，通过 6 个任务型日语页面快速验证需求；暂不自研模型或建设复杂多模型后端。**

## 使用方法
将整个 ZIP 上传至 ChatGPT Work 的项目工作目录/文件区，或把这些 Markdown 文件复制进你的代码仓库 `/docs`。从 `README.md` 开始，让 Agent 读取全部决策文档后再执行任务。

## 质量声明
文件中的时间、价格、关键词难度、工具能力属于规划信息或待验证假设，不代表已完成商用 API 调用、真实用户测试或日本市场定量调查。
