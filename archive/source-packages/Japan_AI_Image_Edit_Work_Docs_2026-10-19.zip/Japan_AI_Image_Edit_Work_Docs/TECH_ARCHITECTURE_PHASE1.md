# Phase 1 技术架构（最小可行版）

## 1. 目标
让 1–2 个经验证的商业图片编辑端点服务 6 个不同任务页面；优先单体部署和少量独立文件。拒绝为未来几十个模型做平台化设计。

```text
Browser (/ja/tools/[slug])
  -> Next.js API (/api/uploads, /api/edit, /api/jobs/[id])
  -> task registry + versioned prompt templates
  -> one commercial API relay provider (server-side key)
  -> results and cost record + credits
  -> download / feedback / analytics
```

## 2. 最小数据表
- `users`: id, created_at, locale, auth_provider。
- `assets`: id, user_id/anonymous_session_id, object_key, mime, size, expires_at。
- `jobs`: id, user_id, task_id, prompt_version, status, provider_job_id, cost_estimated, cost_actual, error_code, created_at, completed_at。
- `credit_ledger`: id, user_id, job_id, delta, reason, timestamp；追加式账本以便审计。
- `events`: session_id, page, source, event_type, task_id, timestamp；严禁将用户照片内容或可识别个人信息写入分析事件。
- `purchases`: id, user_id, payment_provider_id, amount_jpy, currency, status, idempotency_key。

## 3. API 合约示例（内部定义，非上游真实接口）
```json
{"task_id":"photo-to-illustration","asset_id":"upload-123","style_id":"watercolor","user_instruction":""}
```
返回 `job_id` 和内部状态；异步上游用轮询，若上游同步返回也封装为同一任务记录。上传应使用大小限制、白名单、文件校验与临时存储。

## 4. 上游中转站采购核查
- 明确模型 ID、图像编辑和多图编辑是否真实支持、可选输出规格、速率限制、超时和错误码。
- 明确商业使用和作为消费级 SaaS 再提供能力的授权；隐私、删除、训练用途、地域、退款、计费方式。
- 准备 60 张照片、双模型对比；如果只找到一个可合规运行的端点，则先单端点上线。

## 5. 必须做的可靠性，不是过度架构
- 服务端密钥；请求鉴权、频控、滥用限制、每日总费用熔断。
- 余额预留与最终扣费幂等；上游调用失败自动释放预留。
- 最少量任务日志记录成本、时延、状态；审计不存储敏感用户图像内容。
- 上传与结果文件定期清理，提供用户删除请求。
- 对文本指定删除目标设置产品限制；不声称无蒙版精准局部编辑。

## 6. 不做
不做微服务、复杂自动模型路由、多供应商智能故障转移、GPU 自托管、训练、向量数据库、工作流 DAG、专业修图画布。这些由真实指标触发再迭代。
